<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends MY_Controller {
	function __construct(){
		parent::__construct();
		if ($this->session->userdata('status')!="admin") {
			redirect('admin/login');
		}
	}

	function index(){
		$data['view'] = 'v_mahasiswa';
		$data['title'] = 'Mahasiswa';
		$data['side'] = 'index';
		$data['mahasiswa'] = $this->db->query("SELECT a.nim, a.nama, COALESCE(SUM(case when b.validasi = '1' then b.jumlah end),0) saldo, a.aktif FROM mahasiswa a LEFT JOIN topup b USING(nim) GROUP BY a.nim, a.nama, a.aktif")->result();
		$this->master($data);
	}
	function history($nim = null){
		if(strlen($nim) > 0){
			$data['view'] = 'v_mahasiswa_history_topup';
			$data['title'] = 'Mahasiswa';
			$data['side'] = 'index';
			$data['history'] = $this->db->query("SELECT * FROM topup WHERE nim = '$nim'")->result();
			$this->master($data);
		}else{
			redirect('admin');
		}
	}
	function detail_history($id = null){
		if(strlen($id) > 0){
			$data['view'] = 'v_mahasiswa_history_topup_detail';
			$data['title'] = 'Mahasiswa';
			$data['side'] = 'index';
			$data['detail'] = $this->db->query("SELECT a.*, b.nama FROM topup a JOIN mahasiswa b USING(nim) WHERE id_topup = '$id'")->result()[0];
			$this->master($data);
		}else{
			redirect('admin');
		}
	}
	function tambah(){
		$data['view'] = 'v_mahasiswa_add';
		$data['title'] = 'Mahasiswa';
		$data['side'] = 'tambah';
		$this->master($data);
	}
	function add(){
		if($this->input->post('submit')){
			$nim = $this->input->post('nim');
			$nama = $this->input->post('nama');
			$aktif = $this->input->post('status');
			
			$data_insert = array(
				'nim' => $nim,
				'nama' => $nama,
				'aktif' => $aktif
			);
			$this->db->insert('mahasiswa',$data_insert);
			redirect('admin/mahasiswa');
		}else{
			redirect('admin');
		}
	}
	function edit($id = null){
		if(strlen($id) > 0){
			$data['view'] = 'v_mahasiswa_edit';
			$data['title'] = 'Mahasiswa';
			$data['side'] = 'index';
			$data['mahasiswa'] = $this->db->query("SELECT * FROM mahasiswa WHERE nim = '$id'")->result()[0];
			$this->master($data);
		}else{
			redirect('admin');
		}
	}
	function update(){
		if($this->input->post('submit')){
			$nim = $this->input->post('nim');
			$nama = $this->input->post('nama');
			$aktif = $this->input->post('status');
			
			$data_update = array(
				'nama' => $nama,
				'aktif' => $aktif
			);
			$this->db->where('nim',$nim);
			$this->db->update('mahasiswa',$data_update);
			redirect('admin/mahasiswa');
		}else{
			redirect('admin');
		}
	}

	private function master($data){
		$this->load->view('master/header', $data);
		$this->load->view('master/topbar');
		$this->load->view('master/sidebar', $data);
		$this->load->view($data['view'], $data);
		$this->load->view('master/footer');
	}
}
